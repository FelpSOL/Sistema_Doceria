﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using maridoces.DTOs;

namespace maridoces.Utils
{
   public class Carrinho
    {
        public static List<ProdutoDTO> listaDeitensDTO = new List<ProdutoDTO>();
        public static decimal valorTotalCompra;
    }
}
