﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using maridoces.conexao;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace maridoces.Cards
{
    public partial class LoginADM : UserControl
    {
        public LoginADM()
        {
            InitializeComponent();
            Utils.Rounded.setRoundedController(btn_acessar, 10);
        }

        private void btn_acessar_Click(object sender, EventArgs e)
        {
            DataTable Acessar = UsuarioDAL.Entrar(txt_email.Text, txt_senha.Text);

            if (Acessar.Rows.Count > 0)
            {
                this.Controls.Clear();
                Administrador controleADM = new Administrador();
                this.Controls.Add(controleADM);
                controleADM.Dock = DockStyle.Fill;
            }
            else
            {
                MessageBox.Show("Login ou senha invalidos");
            }
        }

       
    }
}
