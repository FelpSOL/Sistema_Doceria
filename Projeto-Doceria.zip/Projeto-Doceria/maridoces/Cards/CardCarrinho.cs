﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using maridoces.conexao;
using maridoces.DTOs;

namespace maridoces.Cards
{
    public partial class CardCarrinho : UserControl
    {
        private int _id_carrinho; //guarda o valor da posição do itemdentro da lista Carrinho
        private decimal _valorProduto;
        public CardCarrinho(ProdutoDTO produto, int indexNaLista) // index na lista novo parametro
        {
            InitializeComponent();

            Utils.Rounded.setRoundedController(this, 25);
            lbl_nomeCC.Text = produto.nome;
            pcx_cardC.ImageLocation = produto.imagem;
            lbl_valorCC.Text = $"R$ {produto.valor.ToString("0.00")}";

            _id_carrinho = indexNaLista;
            _valorProduto = produto.valor;               //dando erro ao tirar o INT

        }

        private void btn_excluirCC_Click(object sender, EventArgs e)
        {

            Utils.Carrinho.listaDeitensDTO.RemoveAt(_id_carrinho);// apaga o item da lista
            Utils.Carrinho.valorTotalCompra -= _valorProduto;
            this.Dispose();//remove o card da tela


        }

    }
}
