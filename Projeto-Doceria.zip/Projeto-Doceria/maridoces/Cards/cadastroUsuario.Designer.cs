﻿namespace maridoces.Cards
{
    partial class cadastroUsuario
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            lbl_administrador = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txt_email = new TextBox();
            textBox1 = new TextBox();
            panel1 = new Panel();
            label4 = new Label();
            panel2 = new Panel();
            btn_debito = new Button();
            btn_credito = new Button();
            btn_dinheiro = new Button();
            btn_continuar = new Button();
            btn_voltar = new Button();
            btn_pix = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pictureBox1.Image = Properties.Resources.Logo;
            pictureBox1.Location = new Point(186, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(139, 150);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 25;
            pictureBox1.TabStop = false;
            // 
            // lbl_administrador
            // 
            lbl_administrador.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lbl_administrador.AutoSize = true;
            lbl_administrador.BackColor = Color.Transparent;
            lbl_administrador.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_administrador.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_administrador.Location = new Point(131, 168);
            lbl_administrador.Name = "lbl_administrador";
            lbl_administrador.Size = new Size(246, 30);
            lbl_administrador.TabIndex = 26;
            lbl_administrador.Text = "Identificação do Pedido";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(67, 36, 24);
            label1.Location = new Point(131, 387);
            label1.Name = "label1";
            label1.Size = new Size(238, 30);
            label1.TabIndex = 27;
            label1.Text = "Método de Pagamento";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(67, 36, 24);
            label2.Location = new Point(26, 33);
            label2.Name = "label2";
            label2.Size = new Size(65, 21);
            label2.TabIndex = 28;
            label2.Text = "Nome :";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(67, 36, 24);
            label3.Location = new Point(42, 87);
            label3.Name = "label3";
            label3.Size = new Size(46, 21);
            label3.TabIndex = 29;
            label3.Text = "CPF :";
            // 
            // txt_email
            // 
            txt_email.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txt_email.BackColor = SystemColors.Info;
            txt_email.Location = new Point(134, 242);
            txt_email.Name = "txt_email";
            txt_email.PlaceholderText = "Digite seu nome ...";
            txt_email.Size = new Size(280, 23);
            txt_email.TabIndex = 30;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.BackColor = SystemColors.Info;
            textBox1.Location = new Point(131, 296);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Digite seu CPF ...";
            textBox1.Size = new Size(283, 23);
            textBox1.TabIndex = 31;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.FromArgb(255, 250, 237);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label3);
            panel1.Location = new Point(37, 211);
            panel1.Name = "panel1";
            panel1.Size = new Size(429, 152);
            panel1.TabIndex = 32;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Nirmala UI Semilight", 8.25F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(67, 36, 24);
            label4.Location = new Point(285, 111);
            label4.Name = "label4";
            label4.Size = new Size(92, 13);
            label4.TabIndex = 30;
            label4.Text = "* Não Obrigatorio";
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel2.BackColor = Color.FromArgb(255, 250, 237);
            panel2.Controls.Add(btn_pix);
            panel2.Controls.Add(btn_debito);
            panel2.Controls.Add(btn_credito);
            panel2.Controls.Add(btn_dinheiro);
            panel2.Location = new Point(37, 438);
            panel2.Name = "panel2";
            panel2.Size = new Size(429, 152);
            panel2.TabIndex = 33;
            // 
            // btn_debito
            // 
            btn_debito.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            btn_debito.BackColor = Color.FromArgb(255, 240, 180);
            btn_debito.Cursor = Cursors.Hand;
            btn_debito.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_debito.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_debito.FlatStyle = FlatStyle.Popup;
            btn_debito.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_debito.ForeColor = Color.FromArgb(67, 36, 24);
            btn_debito.Location = new Point(222, 24);
            btn_debito.Name = "btn_debito";
            btn_debito.Size = new Size(183, 47);
            btn_debito.TabIndex = 34;
            btn_debito.Text = "Cartão de Débito";
            btn_debito.UseVisualStyleBackColor = false;
            // 
            // btn_credito
            // 
            btn_credito.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            btn_credito.BackColor = Color.FromArgb(255, 240, 180);
            btn_credito.Cursor = Cursors.Hand;
            btn_credito.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_credito.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_credito.FlatStyle = FlatStyle.Popup;
            btn_credito.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_credito.ForeColor = Color.FromArgb(67, 36, 24);
            btn_credito.Location = new Point(222, 86);
            btn_credito.Name = "btn_credito";
            btn_credito.Size = new Size(183, 47);
            btn_credito.TabIndex = 33;
            btn_credito.Text = "Cartão de Crédito";
            btn_credito.UseVisualStyleBackColor = false;
            // 
            // btn_dinheiro
            // 
            btn_dinheiro.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            btn_dinheiro.BackColor = Color.FromArgb(255, 240, 180);
            btn_dinheiro.Cursor = Cursors.Hand;
            btn_dinheiro.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_dinheiro.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_dinheiro.FlatStyle = FlatStyle.Popup;
            btn_dinheiro.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_dinheiro.ForeColor = Color.FromArgb(67, 36, 24);
            btn_dinheiro.Location = new Point(26, 24);
            btn_dinheiro.Name = "btn_dinheiro";
            btn_dinheiro.Size = new Size(183, 47);
            btn_dinheiro.TabIndex = 31;
            btn_dinheiro.Text = "Dinheiro";
            btn_dinheiro.UseVisualStyleBackColor = false;
            // 
            // btn_continuar
            // 
            btn_continuar.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btn_continuar.BackColor = Color.FromArgb(117, 209, 197);
            btn_continuar.Cursor = Cursors.Hand;
            btn_continuar.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_continuar.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_continuar.FlatStyle = FlatStyle.Popup;
            btn_continuar.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_continuar.ForeColor = Color.FromArgb(67, 36, 24);
            btn_continuar.Location = new Point(345, 618);
            btn_continuar.Name = "btn_continuar";
            btn_continuar.Size = new Size(121, 34);
            btn_continuar.TabIndex = 34;
            btn_continuar.Text = "Continuar";
            btn_continuar.UseVisualStyleBackColor = false;
            // 
            // btn_voltar
            // 
            btn_voltar.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btn_voltar.AutoEllipsis = true;
            btn_voltar.BackColor = Color.FromArgb(255, 130, 124);
            btn_voltar.Cursor = Cursors.Hand;
            btn_voltar.FlatAppearance.BorderSize = 0;
            btn_voltar.FlatAppearance.MouseDownBackColor = Color.FromArgb(255, 128, 0);
            btn_voltar.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 224, 192);
            btn_voltar.FlatStyle = FlatStyle.Popup;
            btn_voltar.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_voltar.ForeColor = Color.FromArgb(67, 36, 24);
            btn_voltar.Location = new Point(37, 618);
            btn_voltar.Name = "btn_voltar";
            btn_voltar.Size = new Size(121, 34);
            btn_voltar.TabIndex = 35;
            btn_voltar.Text = "Voltar";
            btn_voltar.UseVisualStyleBackColor = false;
            // 
            // btn_pix
            // 
            btn_pix.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            btn_pix.BackColor = Color.FromArgb(255, 240, 180);
            btn_pix.Cursor = Cursors.Hand;
            btn_pix.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_pix.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_pix.FlatStyle = FlatStyle.Popup;
            btn_pix.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_pix.ForeColor = Color.FromArgb(67, 36, 24);
            btn_pix.Location = new Point(26, 86);
            btn_pix.Name = "btn_pix";
            btn_pix.Size = new Size(183, 47);
            btn_pix.TabIndex = 35;
            btn_pix.Text = "PIX";
            btn_pix.UseVisualStyleBackColor = false;
            // 
            // cadastroUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BlanchedAlmond;
            Controls.Add(btn_voltar);
            Controls.Add(btn_continuar);
            Controls.Add(panel2);
            Controls.Add(textBox1);
            Controls.Add(txt_email);
            Controls.Add(label1);
            Controls.Add(lbl_administrador);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Name = "cadastroUsuario";
            Size = new Size(504, 674);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label lbl_administrador;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txt_email;
        private TextBox textBox1;
        private Panel panel1;
        private Label label4;
        private Panel panel2;
        private Button btn_dinheiro;
        private Button btn_debito;
        private Button btn_credito;
        private Button btn_continuar;
        private Button btn_voltar;
        private Button btn_pix;
    }
}
