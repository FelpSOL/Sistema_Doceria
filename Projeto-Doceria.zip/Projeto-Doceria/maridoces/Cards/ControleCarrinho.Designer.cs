﻿namespace maridoces.Cards
{
    partial class ControleCarrinho
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pnl_superiorCarrinho = new Panel();
            lbl_carrinhoQuantidade = new Label();
            lbl_carrinhoPreco = new Label();
            lbl_carrinhoProduto = new Label();
            pnl_inferiorCarrinho = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            checkBox1 = new CheckBox();
            lbl_totalCarrinho = new Label();
            pnl_centroCarrinho = new Panel();
            flp_itensCarrinho = new FlowLayoutPanel();
            pnl_superiorCarrinho.SuspendLayout();
            pnl_inferiorCarrinho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnl_centroCarrinho.SuspendLayout();
            SuspendLayout();
            // 
            // pnl_superiorCarrinho
            // 
            pnl_superiorCarrinho.BackColor = Color.BlanchedAlmond;
            pnl_superiorCarrinho.Controls.Add(lbl_carrinhoQuantidade);
            pnl_superiorCarrinho.Controls.Add(lbl_carrinhoPreco);
            pnl_superiorCarrinho.Controls.Add(lbl_carrinhoProduto);
            pnl_superiorCarrinho.Dock = DockStyle.Top;
            pnl_superiorCarrinho.Location = new Point(0, 0);
            pnl_superiorCarrinho.Name = "pnl_superiorCarrinho";
            pnl_superiorCarrinho.Size = new Size(504, 70);
            pnl_superiorCarrinho.TabIndex = 0;
            // 
            // lbl_carrinhoQuantidade
            // 
            lbl_carrinhoQuantidade.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lbl_carrinhoQuantidade.AutoSize = true;
            lbl_carrinhoQuantidade.BackColor = Color.Transparent;
            lbl_carrinhoQuantidade.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_carrinhoQuantidade.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_carrinhoQuantidade.Location = new Point(405, 32);
            lbl_carrinhoQuantidade.Name = "lbl_carrinhoQuantidade";
            lbl_carrinhoQuantidade.Size = new Size(78, 21);
            lbl_carrinhoQuantidade.TabIndex = 5;
            lbl_carrinhoQuantidade.Text = "Remover";
            // 
            // lbl_carrinhoPreco
            // 
            lbl_carrinhoPreco.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lbl_carrinhoPreco.AutoSize = true;
            lbl_carrinhoPreco.BackColor = Color.Transparent;
            lbl_carrinhoPreco.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_carrinhoPreco.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_carrinhoPreco.Location = new Point(293, 32);
            lbl_carrinhoPreco.Name = "lbl_carrinhoPreco";
            lbl_carrinhoPreco.Size = new Size(50, 21);
            lbl_carrinhoPreco.TabIndex = 4;
            lbl_carrinhoPreco.Text = "Valor";
            // 
            // lbl_carrinhoProduto
            // 
            lbl_carrinhoProduto.AutoSize = true;
            lbl_carrinhoProduto.BackColor = Color.Transparent;
            lbl_carrinhoProduto.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_carrinhoProduto.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_carrinhoProduto.Location = new Point(21, 32);
            lbl_carrinhoProduto.Name = "lbl_carrinhoProduto";
            lbl_carrinhoProduto.Size = new Size(72, 21);
            lbl_carrinhoProduto.TabIndex = 3;
            lbl_carrinhoProduto.Text = "Produto";
            // 
            // pnl_inferiorCarrinho
            // 
            pnl_inferiorCarrinho.BackColor = Color.BlanchedAlmond;
            pnl_inferiorCarrinho.Controls.Add(label1);
            pnl_inferiorCarrinho.Controls.Add(pictureBox1);
            pnl_inferiorCarrinho.Controls.Add(checkBox1);
            pnl_inferiorCarrinho.Controls.Add(lbl_totalCarrinho);
            pnl_inferiorCarrinho.Dock = DockStyle.Bottom;
            pnl_inferiorCarrinho.Location = new Point(0, 576);
            pnl_inferiorCarrinho.Name = "pnl_inferiorCarrinho";
            pnl_inferiorCarrinho.Size = new Size(504, 98);
            pnl_inferiorCarrinho.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(67, 36, 24);
            label1.Location = new Point(304, 35);
            label1.Name = "label1";
            label1.Size = new Size(55, 21);
            label1.TabIndex = 6;
            label1.Text = "Total :";
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            pictureBox1.ErrorImage = Properties.Resources.Star_1;
            pictureBox1.ImageLocation = "https://raw.githubusercontent.com/Roma2250/Imagens/refs/heads/main/imagensVariadasProjetoMN/sacolaviagem.png";
            pictureBox1.Location = new Point(136, 21);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // checkBox1
            // 
            checkBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            checkBox1.AutoSize = true;
            checkBox1.Cursor = Cursors.Hand;
            checkBox1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold);
            checkBox1.ForeColor = Color.FromArgb(67, 36, 24);
            checkBox1.Location = new Point(21, 35);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(123, 25);
            checkBox1.TabIndex = 9;
            checkBox1.Text = "Para viagem";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // lbl_totalCarrinho
            // 
            lbl_totalCarrinho.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            lbl_totalCarrinho.AutoSize = true;
            lbl_totalCarrinho.BackColor = Color.Transparent;
            lbl_totalCarrinho.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_totalCarrinho.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_totalCarrinho.Location = new Point(367, 35);
            lbl_totalCarrinho.Name = "lbl_totalCarrinho";
            lbl_totalCarrinho.Size = new Size(107, 21);
            lbl_totalCarrinho.TabIndex = 6;
            lbl_totalCarrinho.Text = "SubTotal: R$ ";
            // 
            // pnl_centroCarrinho
            // 
            pnl_centroCarrinho.BackColor = Color.FromArgb(255, 250, 237);
            pnl_centroCarrinho.Controls.Add(flp_itensCarrinho);
            pnl_centroCarrinho.Dock = DockStyle.Fill;
            pnl_centroCarrinho.Location = new Point(0, 70);
            pnl_centroCarrinho.Name = "pnl_centroCarrinho";
            pnl_centroCarrinho.Size = new Size(504, 506);
            pnl_centroCarrinho.TabIndex = 1;
            // 
            // flp_itensCarrinho
            // 
            flp_itensCarrinho.BackColor = Color.FromArgb(255, 250, 237);
            flp_itensCarrinho.Dock = DockStyle.Fill;
            flp_itensCarrinho.Location = new Point(0, 0);
            flp_itensCarrinho.Name = "flp_itensCarrinho";
            flp_itensCarrinho.Size = new Size(504, 506);
            flp_itensCarrinho.TabIndex = 0;
            // 
            // ControleCarrinho
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Linen;
            Controls.Add(pnl_centroCarrinho);
            Controls.Add(pnl_inferiorCarrinho);
            Controls.Add(pnl_superiorCarrinho);
            Name = "ControleCarrinho";
            Size = new Size(504, 674);
            pnl_superiorCarrinho.ResumeLayout(false);
            pnl_superiorCarrinho.PerformLayout();
            pnl_inferiorCarrinho.ResumeLayout(false);
            pnl_inferiorCarrinho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnl_centroCarrinho.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel pnl_superiorCarrinho;
        private Panel pnl_inferiorCarrinho;
        private Panel pnl_centroCarrinho;
        private Label lbl_carrinhoProduto;
        private Label lbl_carrinhoQuantidade;
        private Label lbl_carrinhoPreco;
        private Label lbl_totalCarrinho;
        private PictureBox pictureBox1;
        private CheckBox checkBox1;
        private FlowLayoutPanel flp_itensCarrinho;
        private Label label1;
    }
}
