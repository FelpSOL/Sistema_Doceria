﻿namespace maridoces.Cards
{
    partial class PedidoFinalizado
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            btn_fimPagamento = new Button();
            button1 = new Button();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pictureBox1.Image = Properties.Resources.Logo;
            pictureBox1.Location = new Point(186, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(139, 150);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 27;
            pictureBox1.TabStop = false;
            // 
            // btn_fimPagamento
            // 
            btn_fimPagamento.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btn_fimPagamento.BackColor = Color.FromArgb(117, 209, 197);
            btn_fimPagamento.Cursor = Cursors.Hand;
            btn_fimPagamento.FlatAppearance.BorderSize = 0;
            btn_fimPagamento.FlatAppearance.MouseDownBackColor = Color.FromArgb(255, 150, 150);
            btn_fimPagamento.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 130, 124);
            btn_fimPagamento.FlatStyle = FlatStyle.Flat;
            btn_fimPagamento.Font = new Font("Nirmala UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_fimPagamento.ForeColor = Color.Linen;
            btn_fimPagamento.Location = new Point(77, 173);
            btn_fimPagamento.Name = "btn_fimPagamento";
            btn_fimPagamento.Size = new Size(364, 63);
            btn_fimPagamento.TabIndex = 28;
            btn_fimPagamento.Text = "Pedido Finalizado!";
            btn_fimPagamento.UseVisualStyleBackColor = false;
            btn_fimPagamento.Click += btn_fimPagamento_Click;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            button1.BackColor = Color.FromArgb(117, 209, 197);
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(255, 150, 150);
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 130, 124);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Linen;
            button1.Location = new Point(77, 544);
            button1.Name = "button1";
            button1.Size = new Size(364, 63);
            button1.TabIndex = 29;
            button1.Text = "Retire sua nota fiscal abaixo";
            button1.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            pictureBox2.ImageLocation = "https://raw.githubusercontent.com/Roma2250/Imagens/refs/heads/main/imagensVariadasProjetoMN/timer.png";
            pictureBox2.Location = new Point(77, 242);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(364, 296);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 30;
            pictureBox2.TabStop = false;
            // 
            // PedidoFinalizado
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BlanchedAlmond;
            Controls.Add(pictureBox2);
            Controls.Add(button1);
            Controls.Add(btn_fimPagamento);
            Controls.Add(pictureBox1);
            Name = "PedidoFinalizado";
            Size = new Size(504, 674);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Button btn_fimPagamento;
        private Button button1;
        private PictureBox pictureBox2;
    }
}
