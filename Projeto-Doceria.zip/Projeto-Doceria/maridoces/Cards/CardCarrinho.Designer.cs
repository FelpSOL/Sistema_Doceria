﻿namespace maridoces.Cards
{
    partial class CardCarrinho
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pcx_cardC = new PictureBox();
            lbl_valorCC = new Label();
            lbl_nomeCC = new Label();
            btn_excluirCC = new Button();
            ((System.ComponentModel.ISupportInitialize)pcx_cardC).BeginInit();
            SuspendLayout();
            // 
            // pcx_cardC
            // 
            pcx_cardC.BackColor = Color.Transparent;
            pcx_cardC.BackgroundImageLayout = ImageLayout.Center;
            pcx_cardC.Dock = DockStyle.Left;
            pcx_cardC.Location = new Point(0, 0);
            pcx_cardC.Margin = new Padding(0);
            pcx_cardC.Name = "pcx_cardC";
            pcx_cardC.Size = new Size(75, 70);
            pcx_cardC.TabIndex = 1;
            pcx_cardC.TabStop = false;
            // 
            // lbl_valorCC
            // 
            lbl_valorCC.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lbl_valorCC.AutoSize = true;
            lbl_valorCC.BackColor = Color.Transparent;
            lbl_valorCC.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_valorCC.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_valorCC.Location = new Point(326, 24);
            lbl_valorCC.Name = "lbl_valorCC";
            lbl_valorCC.Size = new Size(64, 21);
            lbl_valorCC.TabIndex = 4;
            lbl_valorCC.Text = "R$ 0,00";
            // 
            // lbl_nomeCC
            // 
            lbl_nomeCC.AutoSize = true;
            lbl_nomeCC.BackColor = Color.Transparent;
            lbl_nomeCC.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_nomeCC.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_nomeCC.Location = new Point(78, 25);
            lbl_nomeCC.Name = "lbl_nomeCC";
            lbl_nomeCC.Size = new Size(135, 20);
            lbl_nomeCC.TabIndex = 5;
            lbl_nomeCC.Text = "Nome do Produto";
            // 
            // btn_excluirCC
            // 
            btn_excluirCC.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_excluirCC.BackColor = Color.FromArgb(255, 130, 124);
            btn_excluirCC.Cursor = Cursors.Hand;
            btn_excluirCC.FlatAppearance.BorderSize = 0;
            btn_excluirCC.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_excluirCC.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_excluirCC.FlatStyle = FlatStyle.Flat;
            btn_excluirCC.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_excluirCC.ForeColor = Color.FromArgb(67, 36, 24);
            btn_excluirCC.Location = new Point(448, 0);
            btn_excluirCC.Name = "btn_excluirCC";
            btn_excluirCC.Size = new Size(52, 70);
            btn_excluirCC.TabIndex = 6;
            btn_excluirCC.Text = "❌";
            btn_excluirCC.UseVisualStyleBackColor = false;
            btn_excluirCC.Click += btn_excluirCC_Click;
            // 
            // CardCarrinho
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BlanchedAlmond;
            Controls.Add(btn_excluirCC);
            Controls.Add(lbl_nomeCC);
            Controls.Add(lbl_valorCC);
            Controls.Add(pcx_cardC);
            Name = "CardCarrinho";
            Size = new Size(500, 70);
            ((System.ComponentModel.ISupportInitialize)pcx_cardC).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pcx_cardC;
        private Label lbl_valorCC;
        private Label lbl_nomeCC;
        private Button btn_excluirCC;
    }
}
