﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using maridoces.conexao;

namespace maridoces.Cards
{
    public partial class SaboreCategoria : Form
    {
        public SaboreCategoria()
        {
            InitializeComponent();
            dgv_AdicionarSabor.DataSource = SaborDAL.ListarTodosOsSabores();

            dgv_AdicionarCategoria.DataSource = CategoriaDAL.ListarTodosAsCategorias();
        }

        private void btn_excluirSabor_Click(object sender, EventArgs e)
        {

            if (dgv_AdicionarSabor.SelectedRows.Count > 0 && dgv_AdicionarSabor.SelectedRows.Count <= 1) ;
            int idSaborQueSeraExcluido = Convert.ToInt32(dgv_AdicionarSabor.CurrentRow.Cells["id_sabor"].Value);


            {
                DialogResult escolha = MessageBox.Show(
                    $"Deseja excluir o Sabor de ID:{idSaborQueSeraExcluido}?," +
                    $" \nEstá ação é Permanente.",
                    "Deletar Sabor",

                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (escolha == DialogResult.Yes)
                {
                    SaborDAL.ExcluirSabor(Convert.ToInt32(dgv_AdicionarSabor.CurrentRow.Cells["id_sabor"].Value));
                    btn_atualizarSabor_Click(sender, e);
                }
            }
        }

        private void btn_atualizarSabor_Click(object sender, EventArgs e)
        {

            dgv_AdicionarSabor.DataSource = SaborDAL.ListarTodosOsSabores();
        }

        private void btn_salvarSabor_Click(object sender, EventArgs e)
        {
            SaborDAL.AdicionarSabor(
                txt_SalvarSabor.Text);

        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_excluirCategoria_Click(object sender, EventArgs e)
        {

            if (dgv_AdicionarCategoria.SelectedRows.Count > 0 && dgv_AdicionarCategoria.SelectedRows.Count <= 1) ;
            int idCategoriaExcluido = Convert.ToInt32(dgv_AdicionarCategoria.CurrentRow.Cells["id_categoria"].Value);


            {
                DialogResult escolha = MessageBox.Show(
                    $"Deseja excluir o Categoria de ID:{idCategoriaExcluido}?," +
                    $" \nEstá ação é Permanente.",
                    "Deletar Categoria",

                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (escolha == DialogResult.Yes)
                {
                    CategoriaDAL.ExcluirCategoria(Convert.ToInt32(dgv_AdicionarCategoria.CurrentRow.Cells["id_categoria"].Value));
                    btn_AtualizarCategoria_Click(sender, e);
                }
            }
        }

        private void btn_salvarCategoria_Click(object sender, EventArgs e)
        {
            CategoriaDAL.AdicionarCategoria(
               txt_SalvarCategoria.Text);


        }

        private void btn_AtualizarCategoria_Click(object sender, EventArgs e)
        {
            dgv_AdicionarCategoria.DataSource = CategoriaDAL.ListarTodosAsCategorias();
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

