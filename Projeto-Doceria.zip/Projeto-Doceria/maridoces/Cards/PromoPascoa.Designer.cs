﻿namespace maridoces.Cards
{
    partial class PromoPascoa
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PromoPascoa));
            lbl_carrinhoPreco = new Label();
            panel1 = new Panel();
            lbl_principal = new Label();
            panel2 = new Panel();
            lbl_carrinhoProduto = new Label();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lbl_carrinhoPreco
            // 
            lbl_carrinhoPreco.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lbl_carrinhoPreco.BackColor = Color.Transparent;
            lbl_carrinhoPreco.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_carrinhoPreco.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_carrinhoPreco.Location = new Point(15, 14);
            lbl_carrinhoPreco.Name = "lbl_carrinhoPreco";
            lbl_carrinhoPreco.Size = new Size(428, 223);
            lbl_carrinhoPreco.TabIndex = 5;
            lbl_carrinhoPreco.Text = resources.GetString("lbl_carrinhoPreco.Text");
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 250, 237);
            panel1.Controls.Add(lbl_carrinhoPreco);
            panel1.Location = new Point(25, 330);
            panel1.Name = "panel1";
            panel1.Size = new Size(458, 242);
            panel1.TabIndex = 6;
            // 
            // lbl_principal
            // 
            lbl_principal.AutoSize = true;
            lbl_principal.Font = new Font("Nirmala UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_principal.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_principal.Location = new Point(86, 23);
            lbl_principal.Name = "lbl_principal";
            lbl_principal.Size = new Size(341, 32);
            lbl_principal.TabIndex = 7;
            lbl_principal.Text = "Concorra a um Trio de Ovos!";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 250, 237);
            panel2.Controls.Add(lbl_carrinhoProduto);
            panel2.Location = new Point(25, 586);
            panel2.Name = "panel2";
            panel2.Size = new Size(458, 46);
            panel2.TabIndex = 8;
            // 
            // lbl_carrinhoProduto
            // 
            lbl_carrinhoProduto.AutoSize = true;
            lbl_carrinhoProduto.BackColor = Color.Transparent;
            lbl_carrinhoProduto.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_carrinhoProduto.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_carrinhoProduto.Location = new Point(75, 11);
            lbl_carrinhoProduto.Name = "lbl_carrinhoProduto";
            lbl_carrinhoProduto.Size = new Size(304, 21);
            lbl_carrinhoProduto.TabIndex = 9;
            lbl_carrinhoProduto.Text = "⚠ Consultar informações no caixa ⚠";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.ImageLocation = "https://raw.githubusercontent.com/Roma2250/Imagens/refs/heads/main/imagensVariadasProjetoMN/promopascoa.png";
            pictureBox1.Location = new Point(55, 72);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(401, 246);
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            pictureBox1.WaitOnLoad = true;
            // 
            // PromoPascoa
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BlanchedAlmond;
            Controls.Add(pictureBox1);
            Controls.Add(panel2);
            Controls.Add(lbl_principal);
            Controls.Add(panel1);
            Name = "PromoPascoa";
            Size = new Size(504, 674);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_carrinhoPreco;
        private Panel panel1;
        private Label lbl_principal;
        private Panel panel2;
        private Label lbl_carrinhoProduto;
        private PictureBox pictureBox1;
    }
}
