﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace maridoces.Cards
{
    public partial class ControleCarrinho : UserControl
    {
        public ControleCarrinho()
        {
            InitializeComponent();
            lbl_totalCarrinho.Text = $"R$ {Utils.Carrinho.valorTotalCompra.ToString("0.00")}"; //Adicinei a mascara
            RedesenharTela();
        }
        private void RedesenharTela()
        {
            int indiceDoitemNaLista = 0; //variavel que ira amarzenar o item na lista.
            flp_itensCarrinho.Controls.Clear();
            foreach (var item in Utils.Carrinho.listaDeitensDTO)
            {
                CardCarrinho card = new CardCarrinho(item, indiceDoitemNaLista);

                /// passa o indice do item na lista
                flp_itensCarrinho.Controls.Add(card);
                indiceDoitemNaLista++; //incrementa minha variavel indice lista
                card.Disposed += Card_Disposed;
            }


        }
        private void Card_Disposed(object? sender, EventArgs e)
        {
            lbl_totalCarrinho.Text = $"R$ {Utils.Carrinho.valorTotalCompra.ToString("0.00")}"; //Adicinei a mascara
            RedesenharTela();
        }

    }
}
