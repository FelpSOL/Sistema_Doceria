﻿namespace maridoces.Cards
{
    partial class Nota
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pnl_notaSuperior = new Panel();
            pictureBox1 = new PictureBox();
            lbl_nota = new Label();
            pnl_notaInferior = new Panel();
            btn_prosseguir = new Button();
            pnl_notaCentral = new Panel();
            dgv_nota = new DataGridView();
            pnl_notaSuperior.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnl_notaInferior.SuspendLayout();
            pnl_notaCentral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_nota).BeginInit();
            SuspendLayout();
            // 
            // pnl_notaSuperior
            // 
            pnl_notaSuperior.BackColor = Color.BlanchedAlmond;
            pnl_notaSuperior.Controls.Add(pictureBox1);
            pnl_notaSuperior.Controls.Add(lbl_nota);
            pnl_notaSuperior.Dock = DockStyle.Top;
            pnl_notaSuperior.Location = new Point(0, 0);
            pnl_notaSuperior.Name = "pnl_notaSuperior";
            pnl_notaSuperior.Size = new Size(504, 77);
            pnl_notaSuperior.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.Logo;
            pictureBox1.InitialImage = Properties.Resources.Logo;
            pictureBox1.Location = new Point(326, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 77);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // lbl_nota
            // 
            lbl_nota.AutoSize = true;
            lbl_nota.BackColor = Color.Transparent;
            lbl_nota.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_nota.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_nota.Location = new Point(3, 20);
            lbl_nota.Name = "lbl_nota";
            lbl_nota.Size = new Size(170, 30);
            lbl_nota.TabIndex = 4;
            lbl_nota.Text = "Nota Do Pedido";
            // 
            // pnl_notaInferior
            // 
            pnl_notaInferior.BackColor = Color.BlanchedAlmond;
            pnl_notaInferior.Controls.Add(btn_prosseguir);
            pnl_notaInferior.Dock = DockStyle.Bottom;
            pnl_notaInferior.Location = new Point(0, 594);
            pnl_notaInferior.Name = "pnl_notaInferior";
            pnl_notaInferior.Size = new Size(504, 80);
            pnl_notaInferior.TabIndex = 1;
            // 
            // btn_prosseguir
            // 
            btn_prosseguir.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btn_prosseguir.AutoEllipsis = true;
            btn_prosseguir.BackColor = Color.FromArgb(117, 209, 197);
            btn_prosseguir.Cursor = Cursors.Hand;
            btn_prosseguir.FlatAppearance.BorderSize = 0;
            btn_prosseguir.FlatAppearance.MouseDownBackColor = Color.FromArgb(117, 220, 220);
            btn_prosseguir.FlatAppearance.MouseOverBackColor = Color.FromArgb(117, 209, 197);
            btn_prosseguir.FlatStyle = FlatStyle.Flat;
            btn_prosseguir.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_prosseguir.ForeColor = Color.FromArgb(67, 36, 24);
            btn_prosseguir.Location = new Point(184, 24);
            btn_prosseguir.Name = "btn_prosseguir";
            btn_prosseguir.Size = new Size(145, 31);
            btn_prosseguir.TabIndex = 1;
            btn_prosseguir.Text = "Prosseguir";
            btn_prosseguir.UseVisualStyleBackColor = false;
            // 
            // pnl_notaCentral
            // 
            pnl_notaCentral.BackColor = Color.White;
            pnl_notaCentral.Controls.Add(dgv_nota);
            pnl_notaCentral.Dock = DockStyle.Fill;
            pnl_notaCentral.Location = new Point(0, 77);
            pnl_notaCentral.Name = "pnl_notaCentral";
            pnl_notaCentral.Size = new Size(504, 517);
            pnl_notaCentral.TabIndex = 2;
            // 
            // dgv_nota
            // 
            dgv_nota.BackgroundColor = Color.Linen;
            dgv_nota.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_nota.Dock = DockStyle.Top;
            dgv_nota.Location = new Point(0, 0);
            dgv_nota.Name = "dgv_nota";
            dgv_nota.Size = new Size(504, 517);
            dgv_nota.TabIndex = 0;
            // 
            // Nota
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BlanchedAlmond;
            Controls.Add(pnl_notaCentral);
            Controls.Add(pnl_notaInferior);
            Controls.Add(pnl_notaSuperior);
            Name = "Nota";
            Size = new Size(504, 674);
            pnl_notaSuperior.ResumeLayout(false);
            pnl_notaSuperior.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnl_notaInferior.ResumeLayout(false);
            pnl_notaCentral.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv_nota).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnl_notaSuperior;
        private Panel pnl_notaInferior;
        private Panel pnl_notaCentral;
        private Label lbl_nota;
        private DataGridView dgv_nota;
        private Button btn_prosseguir;
        private PictureBox pictureBox1;
    }
}
