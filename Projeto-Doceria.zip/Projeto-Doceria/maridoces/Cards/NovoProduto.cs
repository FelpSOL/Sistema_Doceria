﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using maridoces.Cards;
using maridoces.conexao;
using maridoces.DTOs;

namespace maridoces
{
    public partial class NovoProduto : Form
    {
        private IEnumerable<ProdutoDTO> _ProdutoSelecionado;

        public NovoProduto()
        {
            InitializeComponent();

            cbx_sabor.DataSource = SaborDAL.ListarTodosOsSabores(); // lista la no combo box como o tipo, "system.etc"
            cbx_sabor.DisplayMember = "nome_sabor"; //tabela de nomes que vai aparecer na combo box, nome que aparece
            cbx_sabor.ValueMember = "id_sabor"; //pegar informaçã

            cbx_categoria.DataSource = CategoriaDAL.ListarTodosAsCategorias(); // lista la no combo box como o tipo, "system.etc"
            cbx_categoria.DisplayMember = "nome_categoria"; //tabela de nomes que vai aparecer na combo box, nome que aparece
            cbx_categoria.ValueMember = "id_categoria"; //pegar informação de qual coluna, id que vai fazer a busca no banco de dados 

            btn_salvar.Click += btn_salvar_Click;

        }


        public NovoProduto(int ID)
        {
            InitializeComponent();
            lbl_nome.Text = "Editar Produto: ";
            this.Text = "Editar Produto";

            cbx_categoria.DataSource = CategoriaDAL.ListarTodosAsCategorias(); // lista la no combo box como o tipo, "system.etc"
            cbx_categoria.DisplayMember = "nome_categoria"; //tabela de nomes que vai aparecer na combo box, nome que aparece
            cbx_categoria.ValueMember = "id_categoria";


            cbx_sabor.DataSource = SaborDAL.ListarTodosOsSabores(); // lista la no combo box como o tipo, "system.etc"
            cbx_sabor.DisplayMember = "nome_sabor"; //tabela de nomes que vai aparecer na combo box, nome que aparece
            cbx_sabor.ValueMember = "id_sabor";

            _ProdutoSelecionado = ProdutosDAL.ListarTodosOsProdutos().Where(item => item.id_produtos == ID);

            txt_nomeProduto.Text = _ProdutoSelecionado.First().nome;
            rtb_descricaoProduto.Text = _ProdutoSelecionado.First().descricao;
            txt_LinkImagem.Text = _ProdutoSelecionado.First().imagem;
            mktb_valor.Text = _ProdutoSelecionado.First().valor.ToString("0000.00");
            cbx_categoria.SelectedValue = _ProdutoSelecionado.First().id_categoria;
            cbx_sabor.SelectedValue = _ProdutoSelecionado.First().id_sabor;
            chk_promocao.Checked = _ProdutoSelecionado.First().promocao;

            btn_salvar.Text = "Salvar ";
            btn_salvar.Click += btn_EditarProduto_Click;
        }

        private void btn_EditarProduto_Click(object sender, EventArgs e)
        {
            ProdutosDAL.EditarProduto(
            txt_nomeProduto.Text,
            rtb_descricaoProduto.Text,
            mktb_valor.Text.Replace(",", ".").Replace(" ", "0"),
            Convert.ToInt32(cbx_categoria.SelectedValue),
            Convert.ToInt32(cbx_sabor.SelectedValue),
            txt_LinkImagem.Text,
            _ProdutoSelecionado.First().id_produtos,
            chk_promocao.Checked

                 );
            this.Close();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_salvar_Click(object sender, EventArgs e)
        {
            ProdutosDAL.AdicionarProduto(
          txt_nomeProduto.Text,
          rtb_descricaoProduto.Text,
          mktb_valor.Text.Replace(",", ".").Replace(" ", "0"),
          Convert.ToInt32(cbx_categoria.SelectedValue),
          Convert.ToInt32(cbx_sabor.SelectedValue),
          txt_LinkImagem.Text,
          chk_promocao.Checked
               );
            this.Close();

        }

        private void btn_adicionar_Click(object sender, EventArgs e)
        {
            SaboreCategoria SaboreCategoria = new SaboreCategoria();
            SaboreCategoria.ShowDialog();
        }
    }
}
