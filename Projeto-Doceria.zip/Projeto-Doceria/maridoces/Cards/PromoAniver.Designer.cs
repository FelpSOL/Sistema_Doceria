﻿namespace maridoces.Cards
{
    partial class PromoAniver
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PromoAniver));
            panel1 = new Panel();
            lbl_carrinhoPreco = new Label();
            lbl_principal = new Label();
            panel2 = new Panel();
            lbl_carrinhoProduto = new Label();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 250, 237);
            panel1.Controls.Add(lbl_carrinhoPreco);
            panel1.Location = new Point(26, 332);
            panel1.Name = "panel1";
            panel1.Size = new Size(458, 234);
            panel1.TabIndex = 7;
            // 
            // lbl_carrinhoPreco
            // 
            lbl_carrinhoPreco.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lbl_carrinhoPreco.BackColor = Color.Transparent;
            lbl_carrinhoPreco.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_carrinhoPreco.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_carrinhoPreco.Location = new Point(16, 32);
            lbl_carrinhoPreco.Name = "lbl_carrinhoPreco";
            lbl_carrinhoPreco.Size = new Size(428, 223);
            lbl_carrinhoPreco.TabIndex = 5;
            lbl_carrinhoPreco.Text = resources.GetString("lbl_carrinhoPreco.Text");
            // 
            // lbl_principal
            // 
            lbl_principal.AutoSize = true;
            lbl_principal.Font = new Font("Nirmala UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_principal.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_principal.Location = new Point(107, 20);
            lbl_principal.Name = "lbl_principal";
            lbl_principal.Size = new Size(315, 32);
            lbl_principal.TabIndex = 8;
            lbl_principal.Text = "Promoções de Aniversário";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 250, 237);
            panel2.Controls.Add(lbl_carrinhoProduto);
            panel2.Location = new Point(26, 587);
            panel2.Name = "panel2";
            panel2.Size = new Size(458, 46);
            panel2.TabIndex = 9;
            // 
            // lbl_carrinhoProduto
            // 
            lbl_carrinhoProduto.AutoSize = true;
            lbl_carrinhoProduto.BackColor = Color.Transparent;
            lbl_carrinhoProduto.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_carrinhoProduto.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_carrinhoProduto.Location = new Point(75, 11);
            lbl_carrinhoProduto.Name = "lbl_carrinhoProduto";
            lbl_carrinhoProduto.Size = new Size(304, 21);
            lbl_carrinhoProduto.TabIndex = 9;
            lbl_carrinhoProduto.Text = "⚠ Consultar informações no caixa ⚠";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.ImageLocation = "https://raw.githubusercontent.com/Roma2250/Imagens/refs/heads/main/imagensVariadasProjetoMN/promofesta.png";
            pictureBox1.Location = new Point(55, 73);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(401, 246);
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            pictureBox1.WaitOnLoad = true;
            // 
            // PromoAniver
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BlanchedAlmond;
            Controls.Add(pictureBox1);
            Controls.Add(panel2);
            Controls.Add(lbl_principal);
            Controls.Add(panel1);
            Name = "PromoAniver";
            Size = new Size(504, 674);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label lbl_carrinhoPreco;
        private Label lbl_principal;
        private Panel panel2;
        private Label lbl_carrinhoProduto;
        private PictureBox pictureBox1;
    }
}
