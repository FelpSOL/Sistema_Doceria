﻿namespace maridoces.Cards
{
    partial class SaboreCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_Sabor = new Label();
            txt_SalvarSabor = new TextBox();
            txt_SalvarCategoria = new TextBox();
            label1 = new Label();
            label2 = new Label();
            panel1 = new Panel();
            btn_cancelar = new Button();
            btn_AtualizarCategoria = new Button();
            dgv_AdicionarCategoria = new DataGridView();
            dgv_AdicionarSabor = new DataGridView();
            btn_excluirCategoria = new Button();
            btn_excluirSabor = new Button();
            btn_fechar = new Button();
            btn_salvarCategoria = new Button();
            btn_addSabor = new Button();
            pictureBox1 = new PictureBox();
            btn_atualizarSabor = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_AdicionarCategoria).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv_AdicionarSabor).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lbl_Sabor
            // 
            lbl_Sabor.AutoSize = true;
            lbl_Sabor.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Sabor.Location = new Point(140, -25);
            lbl_Sabor.Name = "lbl_Sabor";
            lbl_Sabor.Size = new Size(119, 20);
            lbl_Sabor.TabIndex = 0;
            lbl_Sabor.Text = "Adicionar sabor";
            // 
            // txt_SalvarSabor
            // 
            txt_SalvarSabor.BackColor = SystemColors.Info;
            txt_SalvarSabor.Location = new Point(10, 370);
            txt_SalvarSabor.Name = "txt_SalvarSabor";
            txt_SalvarSabor.PlaceholderText = "Digite um sabor para adicionar ...";
            txt_SalvarSabor.Size = new Size(327, 23);
            txt_SalvarSabor.TabIndex = 4;
            // 
            // txt_SalvarCategoria
            // 
            txt_SalvarCategoria.BackColor = SystemColors.Info;
            txt_SalvarCategoria.Location = new Point(10, 613);
            txt_SalvarCategoria.Name = "txt_SalvarCategoria";
            txt_SalvarCategoria.PlaceholderText = "Digite uma categoria para adicionar ...";
            txt_SalvarCategoria.Size = new Size(328, 23);
            txt_SalvarCategoria.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(11, 423);
            label1.Name = "label1";
            label1.Size = new Size(170, 21);
            label1.TabIndex = 6;
            label1.Text = "Adicionar Categoria :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(11, 173);
            label2.Name = "label2";
            label2.Size = new Size(140, 21);
            label2.TabIndex = 10;
            label2.Text = "Adicionar Sabor :";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 224, 179);
            panel1.Controls.Add(btn_cancelar);
            panel1.Controls.Add(btn_AtualizarCategoria);
            panel1.Controls.Add(dgv_AdicionarCategoria);
            panel1.Controls.Add(dgv_AdicionarSabor);
            panel1.Controls.Add(btn_excluirCategoria);
            panel1.Controls.Add(btn_excluirSabor);
            panel1.Controls.Add(btn_fechar);
            panel1.Controls.Add(btn_salvarCategoria);
            panel1.Controls.Add(btn_addSabor);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(txt_SalvarCategoria);
            panel1.Controls.Add(txt_SalvarSabor);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(btn_atualizarSabor);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(488, 725);
            panel1.TabIndex = 17;
            // 
            // btn_cancelar
            // 
            btn_cancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_cancelar.AutoEllipsis = true;
            btn_cancelar.BackColor = Color.FromArgb(255, 130, 124);
            btn_cancelar.Cursor = Cursors.Hand;
            btn_cancelar.FlatAppearance.BorderSize = 0;
            btn_cancelar.FlatAppearance.MouseDownBackColor = Color.FromArgb(255, 128, 0);
            btn_cancelar.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 224, 192);
            btn_cancelar.FlatStyle = FlatStyle.Popup;
            btn_cancelar.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_cancelar.ForeColor = Color.FromArgb(67, 36, 24);
            btn_cancelar.Location = new Point(200, 668);
            btn_cancelar.Name = "btn_cancelar";
            btn_cancelar.Size = new Size(86, 31);
            btn_cancelar.TabIndex = 36;
            btn_cancelar.Text = "Cancelar";
            btn_cancelar.UseVisualStyleBackColor = false;
            btn_cancelar.Click += btn_cancelar_Click;
            // 
            // btn_AtualizarCategoria
            // 
            btn_AtualizarCategoria.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_AtualizarCategoria.BackColor = Color.FromArgb(255, 225, 153);
            btn_AtualizarCategoria.Cursor = Cursors.Hand;
            btn_AtualizarCategoria.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_AtualizarCategoria.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_AtualizarCategoria.FlatStyle = FlatStyle.Popup;
            btn_AtualizarCategoria.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_AtualizarCategoria.ForeColor = Color.FromArgb(67, 36, 24);
            btn_AtualizarCategoria.Location = new Point(345, 457);
            btn_AtualizarCategoria.Name = "btn_AtualizarCategoria";
            btn_AtualizarCategoria.Size = new Size(121, 50);
            btn_AtualizarCategoria.TabIndex = 35;
            btn_AtualizarCategoria.Text = "Atualizar Categoria";
            btn_AtualizarCategoria.UseVisualStyleBackColor = false;
            btn_AtualizarCategoria.Click += btn_AtualizarCategoria_Click;
            // 
            // dgv_AdicionarCategoria
            // 
            dgv_AdicionarCategoria.AllowUserToAddRows = false;
            dgv_AdicionarCategoria.AllowUserToDeleteRows = false;
            dgv_AdicionarCategoria.AllowUserToOrderColumns = true;
            dgv_AdicionarCategoria.BackgroundColor = SystemColors.Info;
            dgv_AdicionarCategoria.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_AdicionarCategoria.Location = new Point(10, 457);
            dgv_AdicionarCategoria.Name = "dgv_AdicionarCategoria";
            dgv_AdicionarCategoria.ReadOnly = true;
            dgv_AdicionarCategoria.Size = new Size(327, 150);
            dgv_AdicionarCategoria.TabIndex = 33;
            // 
            // dgv_AdicionarSabor
            // 
            dgv_AdicionarSabor.AllowUserToAddRows = false;
            dgv_AdicionarSabor.AllowUserToDeleteRows = false;
            dgv_AdicionarSabor.AllowUserToOrderColumns = true;
            dgv_AdicionarSabor.BackgroundColor = SystemColors.Info;
            dgv_AdicionarSabor.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_AdicionarSabor.Location = new Point(11, 210);
            dgv_AdicionarSabor.Name = "dgv_AdicionarSabor";
            dgv_AdicionarSabor.ReadOnly = true;
            dgv_AdicionarSabor.Size = new Size(326, 150);
            dgv_AdicionarSabor.TabIndex = 32;
            // 
            // btn_excluirCategoria
            // 
            btn_excluirCategoria.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_excluirCategoria.BackColor = Color.FromArgb(255, 130, 124);
            btn_excluirCategoria.Cursor = Cursors.Hand;
            btn_excluirCategoria.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_excluirCategoria.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_excluirCategoria.FlatStyle = FlatStyle.Popup;
            btn_excluirCategoria.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_excluirCategoria.ForeColor = Color.FromArgb(67, 36, 24);
            btn_excluirCategoria.Location = new Point(345, 522);
            btn_excluirCategoria.Name = "btn_excluirCategoria";
            btn_excluirCategoria.Size = new Size(121, 50);
            btn_excluirCategoria.TabIndex = 30;
            btn_excluirCategoria.Text = "Excluir Categoria";
            btn_excluirCategoria.UseVisualStyleBackColor = false;
            btn_excluirCategoria.Click += btn_excluirCategoria_Click;
            // 
            // btn_excluirSabor
            // 
            btn_excluirSabor.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_excluirSabor.BackColor = Color.FromArgb(255, 130, 124);
            btn_excluirSabor.Cursor = Cursors.Hand;
            btn_excluirSabor.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_excluirSabor.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_excluirSabor.FlatStyle = FlatStyle.Popup;
            btn_excluirSabor.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_excluirSabor.ForeColor = Color.FromArgb(67, 36, 24);
            btn_excluirSabor.Location = new Point(345, 277);
            btn_excluirSabor.Name = "btn_excluirSabor";
            btn_excluirSabor.Size = new Size(121, 50);
            btn_excluirSabor.TabIndex = 29;
            btn_excluirSabor.Text = "Excluir Sabor";
            btn_excluirSabor.UseVisualStyleBackColor = false;
            btn_excluirSabor.Click += btn_excluirSabor_Click;
            // 
            // btn_fechar
            // 
            btn_fechar.BackColor = Color.FromArgb(255, 130, 124);
            btn_fechar.Cursor = Cursors.Hand;
            btn_fechar.FlatAppearance.BorderSize = 0;
            btn_fechar.FlatStyle = FlatStyle.Popup;
            btn_fechar.Location = new Point(453, 9);
            btn_fechar.Margin = new Padding(0);
            btn_fechar.Name = "btn_fechar";
            btn_fechar.Size = new Size(26, 30);
            btn_fechar.TabIndex = 28;
            btn_fechar.Text = "❌";
            btn_fechar.UseVisualStyleBackColor = false;
            btn_fechar.Click += btn_fechar_Click;
            // 
            // btn_salvarCategoria
            // 
            btn_salvarCategoria.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_salvarCategoria.BackColor = Color.FromArgb(117, 209, 197);
            btn_salvarCategoria.Cursor = Cursors.Hand;
            btn_salvarCategoria.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_salvarCategoria.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_salvarCategoria.FlatStyle = FlatStyle.Popup;
            btn_salvarCategoria.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_salvarCategoria.ForeColor = Color.FromArgb(67, 36, 24);
            btn_salvarCategoria.Location = new Point(345, 586);
            btn_salvarCategoria.Name = "btn_salvarCategoria";
            btn_salvarCategoria.Size = new Size(121, 50);
            btn_salvarCategoria.TabIndex = 27;
            btn_salvarCategoria.Text = "Adicionar Categoria";
            btn_salvarCategoria.UseVisualStyleBackColor = false;
            btn_salvarCategoria.Click += btn_salvarCategoria_Click;
            // 
            // btn_addSabor
            // 
            btn_addSabor.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_addSabor.BackColor = Color.FromArgb(117, 209, 197);
            btn_addSabor.Cursor = Cursors.Hand;
            btn_addSabor.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_addSabor.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_addSabor.FlatStyle = FlatStyle.Popup;
            btn_addSabor.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_addSabor.ForeColor = Color.FromArgb(67, 36, 24);
            btn_addSabor.Location = new Point(345, 343);
            btn_addSabor.Name = "btn_addSabor";
            btn_addSabor.Size = new Size(121, 50);
            btn_addSabor.TabIndex = 26;
            btn_addSabor.Text = "Adicionar Sabor";
            btn_addSabor.UseVisualStyleBackColor = false;
            btn_addSabor.Click += btn_salvarSabor_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Logo;
            pictureBox1.Location = new Point(186, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(139, 150);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            // 
            // btn_atualizarSabor
            // 
            btn_atualizarSabor.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_atualizarSabor.BackColor = Color.FromArgb(255, 225, 153);
            btn_atualizarSabor.Cursor = Cursors.Hand;
            btn_atualizarSabor.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_atualizarSabor.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_atualizarSabor.FlatStyle = FlatStyle.Popup;
            btn_atualizarSabor.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_atualizarSabor.ForeColor = Color.FromArgb(67, 36, 24);
            btn_atualizarSabor.Location = new Point(345, 210);
            btn_atualizarSabor.Name = "btn_atualizarSabor";
            btn_atualizarSabor.Size = new Size(121, 50);
            btn_atualizarSabor.TabIndex = 34;
            btn_atualizarSabor.Text = "Atualizar Sabor";
            btn_atualizarSabor.UseVisualStyleBackColor = false;
            btn_atualizarSabor.Click += btn_atualizarSabor_Click;
            // 
            // SaboreCategoria
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(488, 725);
            Controls.Add(lbl_Sabor);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            MaximizeBox = false;
            MdiChildrenMinimizedAnchorBottom = false;
            MinimizeBox = false;
            Name = "SaboreCategoria";
            StartPosition = FormStartPosition.CenterParent;
            Text = "SaboreCategoria";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_AdicionarCategoria).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv_AdicionarSabor).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_Sabor;
        private TextBox txt_SalvarSabor;
        private TextBox txt_SalvarCategoria;
        private Label label1;
        private Label label2;
        private Button btn_editarSabor;
        private Button btn_addSabor;
        private Button btn_salvarCategoria;
        private Button btn_fechar;
        private Button btn_excluirCategoria;
        private Button btn_excluirSabor;
        private Panel panel1;
        private PictureBox pictureBox1;
        private DataGridView dgv_AdicionarSabor;
        private DataGridView dgv_AdicionarCategoria;
        private Button btn_AtualizarCategoria;
        private Button btn_atualizarSabor;
        private Button btn_cancelar;
    }
}