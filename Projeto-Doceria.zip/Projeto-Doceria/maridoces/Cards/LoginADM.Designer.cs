﻿namespace maridoces.Cards
{
    partial class LoginADM
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            lbl_administrador = new Label();
            label1 = new Label();
            label2 = new Label();
            txt_email = new TextBox();
            txt_senha = new TextBox();
            btn_acessar = new Button();
            panel1 = new Panel();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pictureBox1.Image = Properties.Resources.Logo;
            pictureBox1.Location = new Point(186, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(140, 150);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 24;
            pictureBox1.TabStop = false;
            // 
            // lbl_administrador
            // 
            lbl_administrador.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lbl_administrador.AutoSize = true;
            lbl_administrador.BackColor = Color.Transparent;
            lbl_administrador.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_administrador.ForeColor = Color.FromArgb(67, 36, 24);
            lbl_administrador.Location = new Point(120, 198);
            lbl_administrador.Name = "lbl_administrador";
            lbl_administrador.Size = new Size(267, 30);
            lbl_administrador.TabIndex = 25;
            lbl_administrador.Text = "Campo de Gerenciamento";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(67, 36, 24);
            label1.Location = new Point(31, 38);
            label1.Name = "label1";
            label1.Size = new Size(61, 21);
            label1.TabIndex = 26;
            label1.Text = "Email :";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(67, 36, 24);
            label2.Location = new Point(27, 127);
            label2.Name = "label2";
            label2.Size = new Size(65, 21);
            label2.TabIndex = 27;
            label2.Text = "Senha :";
            // 
            // txt_email
            // 
            txt_email.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txt_email.BackColor = SystemColors.Info;
            txt_email.Location = new Point(76, 321);
            txt_email.Name = "txt_email";
            txt_email.PlaceholderText = "Digite seu email cadastrado ...";
            txt_email.Size = new Size(346, 23);
            txt_email.TabIndex = 28;
            // 
            // txt_senha
            // 
            txt_senha.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txt_senha.BackColor = SystemColors.Info;
            txt_senha.Location = new Point(72, 405);
            txt_senha.Name = "txt_senha";
            txt_senha.PasswordChar = '♥';
            txt_senha.PlaceholderText = "Digite sua senha de acesso ...";
            txt_senha.Size = new Size(350, 23);
            txt_senha.TabIndex = 29;
            // 
            // btn_acessar
            // 
            btn_acessar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_acessar.BackColor = Color.FromArgb(117, 209, 197);
            btn_acessar.Cursor = Cursors.Hand;
            btn_acessar.FlatAppearance.MouseDownBackColor = Color.Tan;
            btn_acessar.FlatAppearance.MouseOverBackColor = Color.Red;
            btn_acessar.FlatStyle = FlatStyle.Popup;
            btn_acessar.Font = new Font("Nirmala UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_acessar.ForeColor = Color.FromArgb(67, 36, 24);
            btn_acessar.Location = new Point(141, 244);
            btn_acessar.Name = "btn_acessar";
            btn_acessar.Size = new Size(121, 34);
            btn_acessar.TabIndex = 30;
            btn_acessar.Text = "Acessar";
            btn_acessar.UseVisualStyleBackColor = false;
            btn_acessar.Click += btn_acessar_Click;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.FromArgb(255, 250, 237);
            panel1.Controls.Add(btn_acessar);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(45, 245);
            panel1.Name = "panel1";
            panel1.Size = new Size(411, 318);
            panel1.TabIndex = 31;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(67, 36, 24);
            label3.Location = new Point(88, 592);
            label3.Name = "label3";
            label3.Size = new Size(322, 46);
            label3.TabIndex = 32;
            label3.Text = "⚠ Caso tenha esquecido alguma das informações de acesso, entre em contato com seu superior";
            // 
            // LoginADM
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 179);
            Controls.Add(label3);
            Controls.Add(txt_senha);
            Controls.Add(txt_email);
            Controls.Add(lbl_administrador);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Name = "LoginADM";
            Size = new Size(505, 677);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label lbl_administrador;
        private Label label1;
        private Label label2;
        private TextBox txt_email;
        private TextBox txt_senha;
        private Button btn_acessar;
        private Panel panel1;
        private Label label3;
    }
}
