﻿namespace maridoces.Cards
{
    partial class AguarPagamento
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            btn_fimPagamento = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pictureBox1.Image = Properties.Resources.Logo;
            pictureBox1.Location = new Point(190, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(139, 150);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 25;
            pictureBox1.TabStop = false;
            // 
            // btn_fimPagamento
            // 
            btn_fimPagamento.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btn_fimPagamento.BackColor = Color.FromArgb(117, 209, 197);
            btn_fimPagamento.Cursor = Cursors.Hand;
            btn_fimPagamento.FlatAppearance.BorderSize = 0;
            btn_fimPagamento.FlatAppearance.MouseDownBackColor = Color.FromArgb(255, 150, 150);
            btn_fimPagamento.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 130, 124);
            btn_fimPagamento.FlatStyle = FlatStyle.Flat;
            btn_fimPagamento.Font = new Font("Nirmala UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_fimPagamento.ForeColor = Color.Linen;
            btn_fimPagamento.Location = new Point(78, 336);
            btn_fimPagamento.Name = "btn_fimPagamento";
            btn_fimPagamento.Size = new Size(364, 63);
            btn_fimPagamento.TabIndex = 26;
            btn_fimPagamento.Text = "Aguardando Pagamento ...";
            btn_fimPagamento.UseVisualStyleBackColor = false;
            // 
            // AguarPagamento
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BlanchedAlmond;
            Controls.Add(btn_fimPagamento);
            Controls.Add(pictureBox1);
            Name = "AguarPagamento";
            Size = new Size(504, 674);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Button btn_fimPagamento;
    }
}
